load("breast_cancer.RData")

### Execute following command only once to install package (latest version)
### if not already available
### rerun if package is updated
# library(devtools)
# install_github("savranciati/pdglasso", build_vignettes=FALSE)
# devtools::install_github("MGallow/GLASSOO")
library(pdglasso)
library(gplots) # needed to reproduce the plot
library(showtext) # needed to reproduce the plot
showtext_auto()

### Plotting function (custom function)
# K -> concentration matrix, needed mostly for passing gene.names;
# some lines inside the function can be commented to produce also a proper heatmap
# (in this case, hcl.colors() must be used as an argument inside the call to heatmap)
# GG -> the graph to be plotted, in coloured format (0, 1, 2)
pretty.map <- function(K,GG){
  
  p <- dim(K)[1]
  q <- p/2
  # heatmap(K, Rowv=NA, Colv=NA, scale = "none",
  #         symm=TRUE, revC=TRUE,
  #         col=hcl.colors(256,palette="Blue-Red"))

  cond.ins <- which( (GG[1:q,1:q]*GG[(q+1):p,(q+1):p])==1 , arr.ind = T)
  GG[cond.ins] <- "\u25CB" ### structural symmetries
  #given the output of array.ind=TRUE only produces positions for LL, need to overwrite the RR block too
  GG[cond.ins+q] <- "\u25CB" ### structural symmetries

  GG[GG==0] <- NA
  GG[GG==1] <- "\u2571" ### asymmetric edges
  # GG[GG==1] <- "\u23AF" ### asymmetric edges
  GG[GG==2] <- "\u25CF" ### parametric symmetries
  GG[lower.tri(GG)] <- NA
  K.names <- dimnames(K)
  K <- matrix(0,p,p)
  dimnames(K) <- K.names
  K[lower.tri(K)] <- NA
  
  return(heatmap.2(K,
                   trace="none",
                   density.info = "none",
                   col=hcl.colors(0,palette="Purple-Green"),
                   Rowv=NA,
                   Colv=NA,
                   dendrogram="none",
                   lmat = rbind(c(0,4),c(2,1),c(0,3)), ## sposta la key sotto il grafico
                   lwid = c(1,10), ## gestione larghezza per la key
                   lhei =  c(1,10,2), ## gestione altezza per la key
                   symm=TRUE,
                   rowsep = q,
                   colsep= q,
                   sepcolor = "black",
                   key=FALSE,
                   # key.title="Concentration value",
                   key.xlab = "",
                   cellnote = GG,
                   notecex = 1,
                   notecol="black",
                   labRow = dimnames(K)[[1]],
                   labCol = dimnames(K)[[2]]
  ))

}


### Data analysis: Breast Cancer data
## import dataset
# data_raw: original dataset
# bc.data: rearranged, final dataset
# S: sample covariance matrix
n <- 114
p <- ncol(S)
q <- p/2



### Mod fV
{
  # technical params
  eps.abs <- eps.rel <- 1e-6
  max_iter <- 5000
  verbose <- FALSE
  lams.max(S)
  # reduced grid after pre-inspecting lambda values
  lams <- rbind(c(0.1, 3.3, 10),
              c(0.05, 1, 10))
  # subclass
  type <- c("v","i","a")
  force.symm <- c("v")
  mod_fV <- pdRCON.fit(S,n,
                  type=type,
                  force.symm = force.symm,
                  lams=lams,
                  max_iter=max_iter,
                  eps.abs=eps.abs, eps.rel=eps.rel,
                  verbose=verbose)

  mod_fV$l1.path
  mod_fV$l2.path
  mod_fV$best.lambdas
  
  G_fV <- pdColG.get(mod_fV$model)
  pdColG.summarize(G_fV$pdColG)
  X_fV <- pdRCON.mle(S,G_fV$pdColG)
  
  
  pdf(file="plot_fV.pdf",
      width=14, height=16)
  pretty.map(cov2cor(X_fV),G_fV$pdColG)
  dev.off()
}

### Mod fVIA
{
  # technical params
  eps.abs <- eps.rel <- 1e-6
  max_iter <- 5000
  verbose <- FALSE
  lams.max(S)
  # reduced grid after pre-inspecting lambda values
  # P.S. the grid for lambda2 is not actually needed because of
  # full parametry symmetry forced with force.symm
  # provide at least 1 value, however
  lams <- rbind(c(0.1, 3.3, 10),
                c(0.05, 1, 1))
  # subclass
  type <- c("v","i","a")
  force.symm <- c("v","i","a")
  mod_fVIA <- pdRCON.fit(S,n,
                         type=type,
                         force.symm = force.symm,
                         lams=lams,
                         max_iter=max_iter,
                         eps.abs=eps.abs, eps.rel=eps.rel,
                         verbose=verbose)
  
  mod_fVIA$l1.path
  mod_fVIA$l2.path
  mod_fVIA$best.lambdas
  
  G_fVIA <- pdColG.get(mod_fVIA$model)
  pdColG.summarize(G_fVIA$pdColG)
  X_fVIA <- pdRCON.mle(S,G_fVIA$pdColG)
  
  
  pdf(file="plot_fV.pdf",
      width=14, height=16)
  pretty.map(cov2cor(X_fVIA),G_fVIA$pdColG)
  dev.off()
}

### Submodels and testing
{
  ## Reference model: mod fVIA
  n.par_fV <- 178/2+133-22/2
  
  #### First submodel sub1_fV (set all across-block edges of mod_fV to 0)
  {
    #copy original graph
    G_sub1 <- G_fV
    G_sub1[1:q,(q+1):p] <- G_sub1[(q+1):p,1:q] <- 0
    
    pdColG.summarize(G_sub1) 
    n.par_sub1 <- 178/2+125-22/2
    
    X_sub1 <- pdRCON.mle(S,G_sub1)
  }
  
  ## Second submodel sub2_fV (keep 1s in G_fV only if structural symmetries = remove inside-block Asymmetries)
  {
    #copy original graph
    G_sub2 <- G_fV
    #check if LL and RR are structural symmetric
    #product of LL*RR is different from zero only if the pair is 2 or if both are 1s
    cond.ins <- which( ((G_sub2[1:q,1:q]*G_sub2[(q+1):p,(q+1):p])==0 & ((G_sub2[1:q,1:q]==1)|(G_sub2[(q+1):p,(q+1):p]==1)) ) , arr.ind = T)
    G_sub2[cond.ins] <- 0
    #given the output of array.ind=TRUE only produces positions for LL, need to overwrite the RR block too
    G_sub2[cond.ins+q] <- 0
    
    pdColG.summarize(G_sub2)
    n.par_sub2 <- 178/2+52-22/2
    
    X_sub2 <- pdRCON.mle(S,G_sub2) 
  }

  #### Third submodel (all inside-block structural symmetries are turned into parametric symmetries; across-block edges not modified)
  {
    #copy original graph
    G_sub3 <- G_fV
    
    cond.ins <- which( (G_sub3[1:q,1:q]*G_sub3[(q+1):p,(q+1):p])==1 , arr.ind = T)
    G_sub3[cond.ins] <- 2
    #given the output of array.ind=TRUE only produces positions for LL, need to overwrite the RR block too
    G_sub3[cond.ins+q] <- 2
    
    pdColG.summarize(G_sub3)
    n.par_sub3 <- 178/2+133-44/2
    
    X_sub3 <- pdRCON.mle(S,G_sub3)

  }
  
  ### Deviance tests (LRTs)
  {
    X_fV[G_fV==0] <- 0 # clean numerical zeros
    ldX_fV <- log(det(X_fV))
    tr_fV <- sum(S*X_fV)
    
    X_sub1[G_sub1==0] <- 0 # clean numerical zeros
    ldX_sub1 <- log(det(X_sub1))
    tr_sub1 <- sum(S*X_sub1)
    
    X_sub2[G_sub2==0] <- 0 # clean numerical zeros
    ldX_sub2 <- log(det(X_sub2))
    tr_sub2 <- sum(S*X_sub2)
    
    X_sub3[G_sub3==0] <- 0 # clean numerical zeros
    ldX_sub3 <- log(det(X_sub3))
    tr_sub3 <- sum(S*X_sub3)
    
  
    cbind(logDets=
            c(ldX_fV, ldX_sub1, ldX_sub2, ldX_sub3),
          Traces=
            c(tr_fV, tr_sub1, tr_sub2, tr_sub3),
          n.pars=
            c(n.par_fV, n.par_sub1, n.par_sub2, n.par_sub3),
          Deviances=c(n*(-ldX_fV+tr_fV),
                      n*(-ldX_sub1+tr_sub1),
                      n*(-ldX_sub2+tr_sub2),
                      n*(-ldX_sub3+tr_sub3))
    )
    
    
    cbind(ChiSQs=
            c(n*(ldX_fV - ldX_sub1 + tr_sub1 - tr_fV),
              n*(ldX_fV - ldX_sub2 + tr_sub2 - tr_fV),
              n*(ldX_fV - ldX_sub3 + tr_sub3 - tr_fV)),
          dfs=
            c(n.par_fV-n.par_sub1,
              n.par_fV-n.par_sub2,
              n.par_fV-n.par_sub3),
          CriticalValues=
            c(qchisq(0.05, df=n.par_fV-n.par_sub1, lower.tail = FALSE),
              qchisq(0.05, df=n.par_fV-n.par_sub2, lower.tail = FALSE),
              qchisq(0.05, df=n.par_fV-n.par_sub3, lower.tail = FALSE))
    )
  }
  
}