library(pdglasso)
library(reshape2)
library(tidyverse)
library(gridExtra)

## Sample sizes
n.list <- c(100,  150,  200,  300,  500,  1000,  1500)
n <- n.list[length(n.list)]
## number of variables
p <- 100

######## Load the appropriate scenario each time before executing the rest
## of the script
#### results for models with no symmetries
load("results_noSym.RData")
res_perf <- results_noSym
res_perf[[17]] <- NULL #comp.times in minutes
#### results for models with 50% symmetries
load("results_halfSym.RData")
res_perf <- c(res_perf,results_halfSym)
res_perf[[33]] <- NULL #comp.times
#### results for models with full symmetries
load("results_fullSym.RData")
res_perf <- c(res_perf,results_fullSym)
res_perf[[49]] <- NULL #comp.times


sizes.name <- paste0(n.list,sep="")
met.name <- rep(c(rep("glasso",8),rep("pdglasso",8)),3)
perf.name <- rep(rep(c("PPV (Precision)","TPR (Recall)","TNR","F1","MCC","Frobenius Norm","Entropy Loss","Number of parameters"),2),3)
dd.names <- rep(rep(1:10,16),3)
scen.names <- c(rep("No Symmetry",16),rep("50% Symmetry",16),rep("Full Symmetry",16))
indiv.scen.names <- c(rep("No Symmetry",16*10),rep("50% Symmetry",16*10),rep("Full Symmetry",16*10))
### Averaged results

# (abs) PPV, TPR, N.par
{
avg.res <- matrix(unlist(lapply(res_perf,colMeans)),16*3,7,byrow=TRUE)
colnames(avg.res) <- sizes.name
rownames(avg.res) <- paste0(scen.names,".",met.name,".",perf.name,sep="")
df <- melt(avg.res)
df <- separate_wider_delim(df,col=1,delim=".",names=c("scen","met","perf"))
names(df) <- c("Scenario","Method","Perf.Mes","Sample.Size","Value")
df$Scenario <- factor(df$Scenario, ordered=TRUE, levels=c("No Symmetry","50% Symmetry","Full Symmetry"))
df$Sample.Size <- factor(df$Sample.Size, ordered = TRUE)
df$Perf.Mes <- factor(df$Perf.Mes, levels=unique(df$Perf.Mes))

df %>%
  filter(Perf.Mes %in% c("PPV (Precision)","TPR (Recall)","Number of parameters")) %>%
  ggplot(aes(x=Sample.Size, y=Value, group=Method)) +
  geom_point(aes(shape=Method), size=1.5)+
  geom_line(aes(linetype=Method),alpha=0.7, linewidth=0.8)+
  ylab("")+
  xlab("Sample Size")+
  facet_grid(Perf.Mes ~ Scenario, scales="free_y")

ggsave(filename="ppv_tpr_npar.pdf",width = 12, height = 7)

# gg_ppv_tpr <- df %>%
#   filter(Perf.Mes %in% c("PPV (Precision)","TPR (Recall)")) %>%
#   ggplot(aes(x=Sample.Size, y=Value, group=Method)) +
#   geom_point(aes(shape=Method), size=1.5)+
#   geom_line(aes(linetype=Method),alpha=0.7, linewidth=0.8)+
#   ylab("")+
#   xlab("Sample Size")+
#   scale_y_continuous(limits = c(0,1))+
#   facet_grid(Perf.Mes ~ Scenario, scales="free_y")
# 
# gg_num_par <- df %>%
#   filter(Perf.Mes %in% c("Number of parameters")) %>%
#   ggplot(aes(x=Sample.Size, y=Value, group=Method)) +
#   geom_point(aes(shape=Method), size=1.5)+
#   geom_line(aes(linetype=Method),alpha=0.7, linewidth=0.8)+
#   ylab("")+
#   xlab("Sample Size")+
#   facet_grid(Perf.Mes ~ Scenario, scales="free_y")
# 
# gridExtra::grid.arrange(gg_ppv_tpr,gg_num_par,ncol=1, heights=c(0.55,0.45))
# gg <- arrangeGrob(gg_ppv_tpr,gg_num_par,ncol=1, heights=c(0.55,0.45))
# ggsave(filename="ppv_tpr_npar.pdf",gg,width = 11, height = 8)

}

# (rel) F1, MCC, Frob, EL
{
  indiv.res <- do.call(rbind, res_perf)
  colnames(indiv.res) <- sizes.name
  rownames(indiv.res) <- paste0(indiv.scen.names,".",rownames(indiv.res),".",dd.names,sep="")
  df <- melt(indiv.res)
  df <- separate_wider_delim(df,col=1,delim=".",names=c("scen","met","perf","Dataset"))
  names(df) <- c("Scenario","Method","Perf.Mes","Dataset","Sample.Size","Value")
  df$Scenario <- factor(df$Scenario, ordered=TRUE, levels=c("No Symmetry","50% Symmetry","Full Symmetry"))
  df$Sample.Size <- factor(df$Sample.Size, ordered = TRUE)
  df$Perf.Mes <- factor(df$Perf.Mes, levels=unique(df$Perf.Mes),
                        labels=unique(perf.name))
  
  df.g <- df %>% filter(Method=="g")
  df.pdg <- df %>% filter(Method=="pdg")
  
  df.avg <- df.pdg
  df.avg$Rel.Diff <- 1
  # df.avg$Rel.Diff <- 100*(abs(df.pdg$Value)-abs(df.g$Value))/abs((df.g$Value))
  
  sel.f1mcc <- df.avg$Perf.Mes %in% c("F1","MCC")
  df.avg$Rel.Diff[sel.f1mcc] <- df.pdg$Value[sel.f1mcc]-df.g$Value[sel.f1mcc]
  sel.fbel <- df.avg$Perf.Mes %in% c("Frobenius Norm","Entropy Loss")
  df.avg$Rel.Diff[sel.fbel] <- 100*(abs(df.pdg$Value[sel.fbel])-abs(df.g$Value[sel.fbel]))/abs((df.g$Value[sel.fbel]))
  
  df.avg <- df.avg %>% group_by(Scenario,Method,Perf.Mes,Sample.Size) %>% summarise(avg.rel.diff=mean(Rel.Diff)) %>% ungroup()
    
  gg_f1mcc <- df.avg %>% 
    filter(Perf.Mes %in% c("F1","MCC")) %>%
    ggplot(aes(x=Sample.Size,y=avg.rel.diff, group=Scenario))+
    geom_point(aes(shape=Scenario), size=2)+
    geom_line(aes(y=0), linewidth=0.9)+
    geom_line(aes(linetype=Scenario),alpha=0.7, linewidth=0.4)+
    ylab("Difference (pdg - glasso)")+
    xlab("Sample Size")+
    facet_wrap(~Perf.Mes, scales="free_y",nrow=1)
  
  gg_fbel <- df.avg %>% 
    filter(Perf.Mes %in% c("Frobenius Norm","Entropy Loss")) %>%
    ggplot(aes(x=Sample.Size,y=avg.rel.diff, group=Scenario))+
    geom_point(aes(shape=Scenario), size=2)+
    geom_line(aes(y=0), linewidth=0.9)+
    geom_line(aes(linetype=Scenario),alpha=0.7, linewidth=0.4)+
    ylab("(Abs.) Relative difference (pdg - glasso)/(glasso)")+
    xlab("Sample Size")+
    facet_wrap(~Perf.Mes, scales="free_y",nrow=1)
 
  gridExtra::grid.arrange(gg_f1mcc,gg_fbel,ncol=1, heights=c(0.5,0.5))
  gg <- arrangeGrob(gg_f1mcc,gg_fbel,ncol=1, heights=c(0.5,0.5))
  ggsave(filename="f1_mcc_frob_el.pdf",gg,width = 11, height = 8)   
}