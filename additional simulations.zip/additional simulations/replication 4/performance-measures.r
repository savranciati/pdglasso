performance.measures <- function(G, Gtrue){
  p       <- dim(G)[1]
  n.edges <- p*(p-1)/2
  GL      <- G != 0
  GLtrue  <- G.true != 0
  P.Gtrue <- sum(GLtrue[upper.tri(GLtrue, diag = FALSE)])
  N.Gtrue <- n.edges - P.Gtrue
  P.G     <- sum(GL[upper.tri(GLtrue, diag = FALSE)])
  N.G     <- n.edges - P.G
  TP      <- sum(GL[upper.tri(GL, diag = FALSE)] & GLtrue[upper.tri(GLtrue, diag = FALSE)])
  FP      <- P.G - TP
  FN      <- P.Gtrue - TP
  TN      <- N.G - FN
  return(list(n.edges=n.edges, P.Gtrue=P.Gtrue, N.Gtrue=N.Gtrue, P.G=P.G, N.G=N.G, TP=TP, FP=FP, TN=TN, FN=FN))
}


PPV <- function(A){return(A$TP/A$P.G)}# Positive Predicted Values or Precision
TPR <- function(A){return(A$TP/A$P.Gtrue)}# True Positive Rate or Recall 
TNR <- function(A){return(A$TN/A$N.Gtrue)}
F1  <- function(A){return(2*A$TP/(2*A$TP+A$FP+A$FN))} # harmonic mean of precision and recall
MCC <- function(A){return((A$TP*A$TN-A$FP*A$FN)/sqrt((A$TP+A$FP)*(A$TP+A$FN)*(A$TN+A$FP)*(A$TN+A$FN)))} #Matthew's Correlacion Coefficient