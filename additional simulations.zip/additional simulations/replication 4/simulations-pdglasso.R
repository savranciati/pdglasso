library(pdglasso)
# Performance measures used in the simulations: PPV, TPR, TNR, F1, MCC, Frobenius Norm, EL
source("performance-measures.r")
## Sample sizes
n.list <- c(100,  150,  200,  300,  500,  1000,  1500)
n <- n.list[length(n.list)]
## number of variables
p <- 100

### Model with no symmetries
##
matPPV.pdg <- matTPR.pdg <- matTNR.pdg <- matF1.pdg <- matMCC.pdg <- c()
matPPV.g <- matTPR.g <- matTNR.g <- matF1.g <- matMCC.g <- c()
matTimes <- c()
matFrob.pdg <- matEL.pdg <- c()
matFrob.g <- matEL.g <- c()
matNpar.pdg <- c()
matNpar.g <- c()
## Load workspace
load("p100_noSym.RData")
for(ii in 1:10){
  ## performances for pdglasso
  pdg.PPV <- c()
  pdg.TPR <- c()
  pdg.TNR <- c()
  pdg.F1  <- c()
  pdg.MCC  <- c()
  ## performances for glasso
  g.PPV <- c()
  g.TPR <- c()
  g.TNR <- c()
  g.F1  <- c()
  g.MCC  <- c()
  comp.times <- c()
  ## Goodness-of-Fit
  pdg.Frob <- c()
  pdg.EL <- c()
  g.Frob <- c()
  g.EL <- c()
  ### Params
  pdg.Npar <- c()
  g.Npar <- c()
  for (n.i in n.list){
    S <- var(gen.mod[[ii]]$sample.data[1:n.i,])
    G.true <- gen.mod[[ii]]$G ## set to pdColG when using symm!=0
    K.true <- gen.mod[[ii]]$K
    S.true <- solve(gen.mod[[ii]]$K)
    fit.out <- pdRCON.fit(S=S, n=n.i, gamma.eBIC = 0.0)
    G.pdg <- pdColG.get(fit.out$model)$pdColG
    admm.out <- admm.pdglasso(S=S, lambda1=fit.out$best.lambdas[1], lambda2=0)
    G.g <- pdColG.get(admm.out)$pdColG
    a.pdg <- performance.measures(G.pdg, G.true)
    a.g   <- performance.measures(G.g,   G.true)
    #
    pdg.PPV <- c(pdg.PPV, PPV(a.pdg))
    pdg.TPR <- c(pdg.TPR, TPR(a.pdg))
    pdg.TNR <- c(pdg.TNR, TNR(a.pdg))
    pdg.F1  <- c(pdg.F1,  F1(a.pdg))
    pdg.MCC  <- c(pdg.MCC,  MCC(a.pdg))
    #
    g.PPV <- c(g.PPV, PPV(a.g))
    g.TPR <- c(g.TPR, TPR(a.g))
    g.TNR <- c(g.TNR, TNR(a.g))
    g.F1  <- c(g.F1,  F1(a.g))
    g.MCC  <- c(g.MCC,  MCC(a.g))
    #
    comp.times <- c(comp.times,fit.out$time.exec)
    #
    pdg.mle <- pdRCON.mle(S,G.pdg)
    g.mle <- pdRCON.mle(S,G.g)
    if(is.null(pdg.mle)){
      pdg.mle <- fit.out$model$X
      prod.pdg_mle <- pdg.mle%*%S.true
      pdg.Frob <- c(pdg.Frob,-norm(K.true-pdg.mle, type="F"))
      pdg.EL <- c(pdg.EL,-((sum(diag(prod.pdg_mle)) - log(det(prod.pdg_mle)) - p)))
    }else{
      prod.pdg_mle <- pdg.mle%*%S.true
      pdg.Frob <- c(pdg.Frob,norm(K.true-pdg.mle, type="F"))
      pdg.EL <- c(pdg.EL,(sum(diag(prod.pdg_mle)) - log(det(prod.pdg_mle)) - p))
    }
    if(is.null(g.mle)){
      g.mle <- admm.out$X
      prod.g_mle <- g.mle%*%S.true
      g.Frob <- c(g.Frob,-norm(K.true-g.mle, type="F"))
      g.EL <- c(g.EL,-((sum(diag(prod.g_mle)) - log(det(prod.g_mle)) - p)))
    }else{
      prod.g_mle <- g.mle%*%S.true
      g.Frob <- c(g.Frob,norm(K.true-g.mle, type="F"))
      g.EL <- c(g.EL,(sum(diag(prod.g_mle)) - log(det(prod.g_mle)) - p))
    }
    pdg.Npar <- c(pdg.Npar,pdColG.get(fit.out$model)$n.par)
    g.Npar <- c(g.Npar,pdColG.get(admm.out)$n.par)
  }
  #
  matPPV.g <- rbind(matPPV.g,g.PPV)
  matTPR.g <- rbind(matTPR.g,g.TPR)
  matTNR.g <- rbind(matTNR.g,g.TNR)
  matF1.g <- rbind(matF1.g,g.F1)
  matMCC.g <- rbind(matMCC.g,g.MCC)
  #
  matPPV.pdg <- rbind(matPPV.pdg,pdg.PPV)
  matTPR.pdg <- rbind(matTPR.pdg,pdg.TPR)
  matTNR.pdg <- rbind(matTNR.pdg,pdg.TNR)
  matF1.pdg <- rbind(matF1.pdg,pdg.F1)
  matMCC.pdg <- rbind(matMCC.pdg,pdg.MCC)
  #
  matTimes <- rbind(matTimes,comp.times)
  #
  matFrob.pdg <- rbind(matFrob.pdg,pdg.Frob)
  matFrob.g <- rbind(matFrob.g,g.Frob)
  matEL.pdg <- rbind(matEL.pdg,pdg.EL)
  matEL.g <- rbind(matEL.g,g.EL)
  #
  matNpar.pdg <- rbind(matNpar.pdg,pdg.Npar)
  matNpar.g <- rbind(matNpar.g,g.Npar)
}
results_noSym <- list(matPPV.g,matTPR.g,matTNR.g,matF1.g,matMCC.g,matFrob.g, matEL.g,matNpar.g,
                      matPPV.pdg,matTPR.pdg,matTNR.pdg,matF1.pdg,matMCC.pdg,matFrob.pdg,matEL.pdg,matNpar.pdg,
                      matTimes)
save(results_noSym,file="results_noSym.RData")



### Model with 50% symmetries
##
matPPV.pdg <- matTPR.pdg <- matTNR.pdg <- matF1.pdg <- matMCC.pdg <- c()
matPPV.g <- matTPR.g <- matTNR.g <- matF1.g <- matMCC.g <- c()
matTimes <- c()
matFrob.pdg <- matEL.pdg <- c()
matFrob.g <- matEL.g <- c()
matNpar.pdg <- c()
matNpar.g <- c()
## Load workspace
load("p100_halfSym.RData")
for(ii in 1:10){
  ## performances for pdglasso
  pdg.PPV <- c()
  pdg.TPR <- c()
  pdg.TNR <- c()
  pdg.F1  <- c()
  pdg.MCC  <- c()
  ## performances for glasso
  g.PPV <- c()
  g.TPR <- c()
  g.TNR <- c()
  g.F1  <- c()
  g.MCC  <- c()
  comp.times <- c()
  ## Goodness-of-Fit
  pdg.Frob <- c()
  pdg.EL <- c()
  g.Frob <- c()
  g.EL <- c()
  ### Params
  pdg.Npar <- c()
  g.Npar <- c()
  for (n.i in n.list){
    S <- var(gen.mod[[ii]]$sample.data[1:n.i,])
    G.true <- gen.mod[[ii]]$pdColG
    K.true <- gen.mod[[ii]]$K
    S.true <- solve(gen.mod[[ii]]$K)
    fit.out <- pdRCON.fit(S=S, n=n.i, gamma.eBIC = 0.0)
    G.pdg <- pdColG.get(fit.out$model)$pdColG
    admm.out <- admm.pdglasso(S=S, lambda1=fit.out$best.lambdas[1], lambda2=0)
    G.g <- pdColG.get(admm.out)$pdColG
    a.pdg <- performance.measures(G.pdg, G.true)
    a.g   <- performance.measures(G.g,   G.true)
    #
    pdg.PPV <- c(pdg.PPV, PPV(a.pdg))
    pdg.TPR <- c(pdg.TPR, TPR(a.pdg))
    pdg.TNR <- c(pdg.TNR, TNR(a.pdg))
    pdg.F1  <- c(pdg.F1,  F1(a.pdg))
    pdg.MCC  <- c(pdg.MCC,  MCC(a.pdg))
    #
    g.PPV <- c(g.PPV, PPV(a.g))
    g.TPR <- c(g.TPR, TPR(a.g))
    g.TNR <- c(g.TNR, TNR(a.g))
    g.F1  <- c(g.F1,  F1(a.g))
    g.MCC  <- c(g.MCC,  MCC(a.g))
    #
    comp.times <- c(comp.times,fit.out$time.exec)
    #
    pdg.mle <- pdRCON.mle(S,G.pdg)
    g.mle <- pdRCON.mle(S,G.g)
    if(is.null(pdg.mle)){
      pdg.mle <- fit.out$model$X
      prod.pdg_mle <- pdg.mle%*%S.true
      pdg.Frob <- c(pdg.Frob,-norm(K.true-pdg.mle, type="F"))
      pdg.EL <- c(pdg.EL,-((sum(diag(prod.pdg_mle)) - log(det(prod.pdg_mle)) - p)))
    }else{
      prod.pdg_mle <- pdg.mle%*%S.true
      pdg.Frob <- c(pdg.Frob,norm(K.true-pdg.mle, type="F"))
      pdg.EL <- c(pdg.EL,(sum(diag(prod.pdg_mle)) - log(det(prod.pdg_mle)) - p))
    }
    if(is.null(g.mle)){
      g.mle <- admm.out$X
      prod.g_mle <- g.mle%*%S.true
      g.Frob <- c(g.Frob,-norm(K.true-g.mle, type="F"))
      g.EL <- c(g.EL,-((sum(diag(prod.g_mle)) - log(det(prod.g_mle)) - p)))
    }else{
      prod.g_mle <- g.mle%*%S.true
      g.Frob <- c(g.Frob,norm(K.true-g.mle, type="F"))
      g.EL <- c(g.EL,(sum(diag(prod.g_mle)) - log(det(prod.g_mle)) - p))
    }
    pdg.Npar <- c(pdg.Npar,pdColG.get(fit.out$model)$n.par)
    g.Npar <- c(g.Npar,pdColG.get(admm.out)$n.par)
    
  }
  #
  matPPV.g <- rbind(matPPV.g,g.PPV)
  matTPR.g <- rbind(matTPR.g,g.TPR)
  matTNR.g <- rbind(matTNR.g,g.TNR)
  matF1.g <- rbind(matF1.g,g.F1)
  matMCC.g <- rbind(matMCC.g,g.MCC)
  #
  matPPV.pdg <- rbind(matPPV.pdg,pdg.PPV)
  matTPR.pdg <- rbind(matTPR.pdg,pdg.TPR)
  matTNR.pdg <- rbind(matTNR.pdg,pdg.TNR)
  matF1.pdg <- rbind(matF1.pdg,pdg.F1)
  matMCC.pdg <- rbind(matMCC.pdg,pdg.MCC)
  #
  matTimes <- rbind(matTimes,comp.times)
  #
  matFrob.pdg <- rbind(matFrob.pdg,pdg.Frob)
  matFrob.g <- rbind(matFrob.g,g.Frob)
  matEL.pdg <- rbind(matEL.pdg,pdg.EL)
  matEL.g <- rbind(matEL.g,g.EL)
  #
  matNpar.pdg <- rbind(matNpar.pdg,pdg.Npar)
  matNpar.g <- rbind(matNpar.g,g.Npar)
  
}
results_halfSym <- list(matPPV.g,matTPR.g,matTNR.g,matF1.g,matMCC.g,matFrob.g, matEL.g,matNpar.g,
                        matPPV.pdg,matTPR.pdg,matTNR.pdg,matF1.pdg,matMCC.pdg,matFrob.pdg,matEL.pdg,matNpar.pdg,
                        matTimes)
save(results_halfSym,file="results_halfSym.RData")


### Model with full symmetries
##
matPPV.pdg <- matTPR.pdg <- matTNR.pdg <- matF1.pdg <- matMCC.pdg <- c()
matPPV.g <- matTPR.g <- matTNR.g <- matF1.g <- matMCC.g <- c()
matTimes <- c()
matFrob.pdg <- matEL.pdg <- c()
matFrob.g <- matEL.g <- c()
matNpar.pdg <- c()
matNpar.g <- c()
## Load workspace
load("p100_fullSym.RData")
for(ii in 1:10){
  ## performances for pdglasso
  pdg.PPV <- c()
  pdg.TPR <- c()
  pdg.TNR <- c()
  pdg.F1  <- c()
  pdg.MCC  <- c()
  ## performances for glasso
  g.PPV <- c()
  g.TPR <- c()
  g.TNR <- c()
  g.F1  <- c()
  g.MCC  <- c()
  comp.times <- c()
  ## Goodness-of-Fit
  pdg.Frob <- c()
  pdg.EL <- c()
  g.Frob <- c()
  g.EL <- c()
  ### Params
  pdg.Npar <- c()
  g.Npar <- c()
  for (n.i in n.list){
    S <- var(gen.mod[[ii]]$sample.data[1:n.i,])
    G.true <- gen.mod[[ii]]$pdColG
    K.true <- gen.mod[[ii]]$K
    S.true <- solve(gen.mod[[ii]]$K)
    fit.out <- pdRCON.fit(S=S, n=n.i, gamma.eBIC = 0.0)
    G.pdg <- pdColG.get(fit.out$model)$pdColG
    admm.out <- admm.pdglasso(S=S, lambda1=fit.out$best.lambdas[1], lambda2=0)
    G.g <- pdColG.get(admm.out)$pdColG
    a.pdg <- performance.measures(G.pdg, G.true)
    a.g   <- performance.measures(G.g,   G.true)
    #
    pdg.PPV <- c(pdg.PPV, PPV(a.pdg))
    pdg.TPR <- c(pdg.TPR, TPR(a.pdg))
    pdg.TNR <- c(pdg.TNR, TNR(a.pdg))
    pdg.F1  <- c(pdg.F1,  F1(a.pdg))
    pdg.MCC  <- c(pdg.MCC,  MCC(a.pdg))
    #
    g.PPV <- c(g.PPV, PPV(a.g))
    g.TPR <- c(g.TPR, TPR(a.g))
    g.TNR <- c(g.TNR, TNR(a.g))
    g.F1  <- c(g.F1,  F1(a.g))
    g.MCC  <- c(g.MCC,  MCC(a.g))
    #
    comp.times <- c(comp.times,fit.out$time.exec)
    #
    pdg.mle <- pdRCON.mle(S,G.pdg)
    g.mle <- pdRCON.mle(S,G.g)
    if(is.null(pdg.mle)){
      pdg.mle <- fit.out$model$X
      prod.pdg_mle <- pdg.mle%*%S.true
      pdg.Frob <- c(pdg.Frob,-norm(K.true-pdg.mle, type="F"))
      pdg.EL <- c(pdg.EL,-((sum(diag(prod.pdg_mle)) - log(det(prod.pdg_mle)) - p)))
    }else{
      prod.pdg_mle <- pdg.mle%*%S.true
      pdg.Frob <- c(pdg.Frob,norm(K.true-pdg.mle, type="F"))
      pdg.EL <- c(pdg.EL,(sum(diag(prod.pdg_mle)) - log(det(prod.pdg_mle)) - p))
    }
    if(is.null(g.mle)){
      g.mle <- admm.out$X
      prod.g_mle <- g.mle%*%S.true
      g.Frob <- c(g.Frob,-norm(K.true-g.mle, type="F"))
      g.EL <- c(g.EL,-((sum(diag(prod.g_mle)) - log(det(prod.g_mle)) - p)))
    }else{
      prod.g_mle <- g.mle%*%S.true
      g.Frob <- c(g.Frob,norm(K.true-g.mle, type="F"))
      g.EL <- c(g.EL,(sum(diag(prod.g_mle)) - log(det(prod.g_mle)) - p))
    }
    pdg.Npar <- c(pdg.Npar,pdColG.get(fit.out$model)$n.par)
    g.Npar <- c(g.Npar,pdColG.get(admm.out)$n.par)
    
  }
  #
  matPPV.g <- rbind(matPPV.g,g.PPV)
  matTPR.g <- rbind(matTPR.g,g.TPR)
  matTNR.g <- rbind(matTNR.g,g.TNR)
  matF1.g <- rbind(matF1.g,g.F1)
  matMCC.g <- rbind(matMCC.g,g.MCC)
  #
  matPPV.pdg <- rbind(matPPV.pdg,pdg.PPV)
  matTPR.pdg <- rbind(matTPR.pdg,pdg.TPR)
  matTNR.pdg <- rbind(matTNR.pdg,pdg.TNR)
  matF1.pdg <- rbind(matF1.pdg,pdg.F1)
  matMCC.pdg <- rbind(matMCC.pdg,pdg.MCC)
  #
  matTimes <- rbind(matTimes,comp.times)
  #
  matFrob.pdg <- rbind(matFrob.pdg,pdg.Frob)
  matFrob.g <- rbind(matFrob.g,g.Frob)
  matEL.pdg <- rbind(matEL.pdg,pdg.EL)
  matEL.g <- rbind(matEL.g,g.EL)
  #
  matNpar.pdg <- rbind(matNpar.pdg,pdg.Npar)
  matNpar.g <- rbind(matNpar.g,g.Npar)
  
}
results_fullSym <- list(matPPV.g,matTPR.g,matTNR.g,matF1.g,matMCC.g,matFrob.g, matEL.g,matNpar.g,
                        matPPV.pdg,matTPR.pdg,matTNR.pdg,matF1.pdg,matMCC.pdg,matFrob.pdg,matEL.pdg,matNpar.pdg,
                        matTimes)
save(results_fullSym,file="results_fullSym.RData")