### R Version and specifics used for the generation scheme (useful if seeds tables change from version to version) 
### R version 4.2.2 (2022-10-31)

library(pdglasso)
## Sample sizes
n.list <- c(100,  150,  200,  300,  500,  1000,  1500)
n <- n.list[length(n.list)]
## number of variables
p <- 100
gen_seed <- round(runif(1,0,10000))

## Datasets generation
### generate model with no symmetries
gen.mod <- list()
for(ii in 1:10){
  #set.seed(1233+ii)
  set.seed(gen_seed+ii)
  gen.mod[[ii]] <- GGM.simulate(p=p, concent.mat = TRUE, sample = TRUE, Sigma=NULL, sample.size = n, dens=0.20)
}  
save(gen.mod,file=paste0("p",p,"_noSym.RData",sep=""))

###  generate 50% symmetric model
gen.mod <- list()
for(ii in 1:10){
  #set.seed(1233+ii)
  set.seed(gen_seed+ii)
  dd <- 0.16
  dd.s <- 0.1
  gen.mod[[ii]] <- pdRCON.simulate(p, type=c("v", "i", "a"),  sample.size=n, dens=dd, dens.vertex = 0.5, dens.inside = dd.s, dens.across = dd.s)
}  
save(gen.mod,file=paste0("p",p,"_halfSym.RData",sep=""))

###  generate fully symmetric model
gen.mod <- list()
for(ii in 1:10){
  #set.seed(1233+ii)
  set.seed(gen_seed+ii)
  dd <- 0.16
  dd.s <- 0.08
  gen.mod[[ii]] <- pdRCON.simulate(p, type=c("v", "i", "a"), force.symm=c("v", "i", "a"), sample.size=n, dens=0.20)
}  
save(gen.mod,file=paste0("p",p,"_fullSym.RData",sep=""))
write.table(gen_seed,file="gen_seed.txt", col.names = FALSE, row.names = FALSE)
